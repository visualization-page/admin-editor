<template>
  <div class="basic-div">
    <slot />
  </div>
</template>

<script lang="ts">
export default {
  name: 'basic-ym'
}
</script>

